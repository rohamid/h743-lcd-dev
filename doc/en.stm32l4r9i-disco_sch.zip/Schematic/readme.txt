******************************************************************************
* @file    readme.txt
* @author  MCD Application Team
* @version V3.0
* @date    20-November-2019  
* @brief   32L4R9IDISCOVERY Schematic files package
******************************************************************************
* COPYRIGHT(c) 2019 STMicroelectronics
*
* The Open Platform License Agreement (�Agreement�) is a binding legal contract
* between you ("You") and STMicroelectronics International N.V. (�ST�), a
* company incorporated under the laws of the Netherlands acting for the purpose
* of this Agreement through its Swiss branch 39, Chemin du Champ des Filles,
* 1228 Plan-les-Ouates, Geneva, Switzerland.
*
* By using the enclosed reference designs, schematics, PC board layouts, and
* documentation, in hardcopy or CAD tool file format (collectively, the
* �Reference Material�), You are agreeing to be bound by the terms and
* conditions of this Agreement. Do not use the Reference Material until You
* have read and agreed to this Agreement terms and conditions. The use of
* the Reference Material automatically implies the acceptance of the Agreement
* terms and conditions.
*
* The complete Open Platform License Agreement can be found on www.st.com/opla.
******************************************************************************

===========================
* V1.0 - 27-September-2017
===========================
    + Created.
 
===========================
* V2.0 - 11-October-2017
===========================
    + Added New schematics related to MB1311C-02 (they are exactly the same than MB1311C-01, because only Bootloader version of STM32L4R9AII6
      have changed on MB1311C-02 : V 9.2 )

===========================
* V3.0 - 20-November-2019
===========================
    + Note that MB1314-B01_schematic.pdf applies also to boards marked with MB1314 B-03 sticker 
    + Added New schematics related to MB1314C-01 (new LCD module with new connectors references and connect two CN3 pads to GND)



******************* (C) COPYRIGHT 2019 STMicroelectronics *****END OF FILE
